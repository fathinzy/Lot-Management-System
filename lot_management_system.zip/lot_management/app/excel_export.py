"""
excel_export.py
Feeds an Excel workbook that other label-printing software (BarTender,
NiceLabel, etc.) can point at as a data source - no manual copy/paste.

Two ways rows get in:
  1. export_pullout_rows() - dumps every line item of a pull-out record
     straight from the database (used by the "Export to Excel" button).
  2. append_scanned_payload() - takes a raw scanned barcode string (same
     format printed on the Packing List) and appends it as a row (used
     by the Label Scan Station in Tab 5).

Both write into the same workbook/sheet so everything ends up in one
place, in the same column layout, for downstream tools to consume.
"""
import os
from openpyxl import Workbook, load_workbook
from . import label_payload as lp

SHEET_NAME = "Label Data"
HEADERS = [lp.LINE_FIELD_LABELS[k] for k in lp.LINE_FIELD_ORDER]


def _open_or_create(xlsx_path):
    if os.path.exists(xlsx_path):
        wb = load_workbook(xlsx_path)
        if SHEET_NAME not in wb.sheetnames:
            ws = wb.create_sheet(SHEET_NAME)
            ws.append(HEADERS)
        else:
            ws = wb[SHEET_NAME]
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = SHEET_NAME
        ws.append(HEADERS)
    return wb, ws


def append_scanned_payload(xlsx_path, payload):
    """payload: the raw pipe-delimited string scanned off a printed barcode."""
    data = lp.parse_line_payload(payload)
    wb, ws = _open_or_create(xlsx_path)
    ws.append([data.get(k, "") for k in lp.LINE_FIELD_ORDER])
    wb.save(xlsx_path)
    return data


def export_pullout_rows(xlsx_path, pullout, pullout_lots):
    """Writes one row per source lot line item for this pull-out, without
    requiring a physical scan - useful for back-office bulk export."""
    wb, ws = _open_or_create(xlsx_path)
    count = 0
    for pl in pullout_lots:
        payload = lp.build_line_payload(pullout, pl)
        data = lp.parse_line_payload(payload)
        ws.append([data.get(k, "") for k in lp.LINE_FIELD_ORDER])
        count += 1
    wb.save(xlsx_path)
    return count
